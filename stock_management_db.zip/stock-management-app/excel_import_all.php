<?php include 'db.php'; ?>
<?php include 'header.php'; ?>

<div class="content-body">
  <div class="container">

    <div class="row my-4">
      <div class="col-md-12">
        <div class="box">
          <div class="box-body">
            <h2 class="my-2">Import All Product From Excel File</h2>
            <form action="excel_import.php" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-4">
                  <input type="file" accept=".csv" name="excel_file" class="form-control" required>
                  <p class="help-block">Only CSV File Import.</p>
                </div>
                <div class="col-md-4">
                  <button name="excel_import" class="btn btn-primary">Excel Import</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<?php include 'footer.php'; ?>
<script language="JavaScript" type="text/javascript">
function checkDelete() {
  return confirm('Are you sure delete?');
}
</script>