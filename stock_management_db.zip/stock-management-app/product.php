 <?php include 'db.php'; ?>
 <?php include 'header.php'; ?>
 <?php include 'product_process.php'; ?>


 <div class="content-body">
   <div class="container">

     <div class="row">
       <div class="col-md-12">
         <!-- <h4 class="page-title">All Product</h4> -->
         <?php
          if (isset($_SESSION['message'])) { ?>
         <div class="alert alert-success alert-dismissible fade show" role="alert">
           <?php echo $_SESSION['message']; ?>
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
         <?php
            unset($_SESSION['message']);
          } ?>
       </div>


       <div class="offset-md-1 col-md-10 offset-xl-2 col-xl-8 mb-5">
         <div class="brand-name-form cmn-form-design">
           <form id="brand-name-form" action="" method="POST" enctype="multipart/form-data">
             <input type="hidden" name="updateId" value="<?php echo $id;  ?>">
             <h2 class="form-title">
               <?php if (isset($product_row["name"])) {
                  echo '
                  Edit Product Information
                  ';
                } else {
                  echo '
                   Add New Product
                    ';
                } ?>
             </h2>
             <div class="form-group">
               <label for="product-name">Product Name</label>
               <input name="name" id="product-name" type="text" class="form-control" placeholder="Type product name"
                 value="<?php echo (isset($product_row['name']) ? $product_row['name'] : '') ?>">
               <div class="invalid-feedback"></div>
             </div>
             <div class="form-row mb-2">
               <div class="col">
                 <label for="category-name">Category</label>

                 <select name="category" id="category-name" class="form-control" required>
                   <option value="">---Select Category---</option>

                   <?php
                    while ($row = mysqli_fetch_assoc($categories)) {
                    ?>

                   <option <?php
                              if (isset($product_row['category_id']) && isset($row['id'])) {
                                echo ($product_row['category_id'] == $row['id'] ? 'selected' : '');
                              } ?> value="<?php echo $row['id'] ?>">
                     <?php echo $row['category_name'] ?>
                   </option>

                   <?php } ?>
                 </select>
                 <div class="invalid-feedback"></div>
               </div>
               <div class="col">
                 <label for="brand-name">Brand</label>
                 <select name="brand" id="brand-name" class="form-control" required>
                   <option value="">---Select Brand---</option>
                   <?php
                    while ($row = mysqli_fetch_assoc($brands)) {
                    ?>
                   <option <?php
                              if (isset($product_row['brand_id']) && isset($row['id'])) {
                                echo ($product_row['brand_id'] == $row['id'] ? 'selected' : '');
                              }
                              ?> value="<?php echo $row['id'] ?>">
                     <?php echo $row['brand_name'] ?>
                   </option>
                   <?php } ?>
                 </select>
                 <div class="invalid-feedback"></div>
               </div>
             </div>
             <div class="form-row mb-2">
               <div class="col">
                 <label for="price">Price</label>
                 <input id="price" name="price" type="text" class="form-control" placeholder="Type price"
                   value="<?php echo (isset($product_row['price']) ? $product_row['price'] : ''); ?>">
                 <div class="invalid-feedback"></div>
               </div>
               <div class="col">
                 <label for="quantity">Quantity</label>
                 <input id="quantity" name="quantity" type="text" class="form-control" placeholder="Type quantity"
                   value="<?php echo (isset($product_row['quantity']) ? $product_row['quantity'] : ''); ?>">
                 <div class="invalid-feedback"></div>
               </div>
             </div>
             <div class="form-row mb-2">
               <div class="col">
                 <label for="product-image">Image</label>
                 <input accept=".jpg,.jpeg,.png" id="product-image" name="image" type="file" class="form-control-file">
               </div>
               <div class="col">
                 <img width="150px" class="img-fluid" src="./uploads/<?php echo $product_row['image']; ?>" alt="">
               </div>

               <div class="invalid-feedback"></div>
             </div>
             <div class="form-group">
               <label for="description">Description</label>

               <textarea name="description" id="editor1" cols="30" rows="10"
                 class="form-control"><?php echo (isset($product_row['description']) ? $product_row['description'] : ''); ?></textarea>
             </div>

             <?php if (isset($product_row["name"])) {
                echo '
                  <div class="cmn-btn-design update">
                    <button class="btn" id="category-update" name="update" type="submit">Update</button>
                    </div>
                  ';
              } else {
                echo '
                    <div class="cmn-btn-design">
                      <button class="btn" id="category-add" name="product_save" type="submit">Add</button>
                    </div>
                    ';
              } ?>



           </form>
         </div>
       </div>

       <!-- <a class="btn btn-primary" href="product_create.php">Add New</a> -->


       <?php
        // get category and brand again
        $categories_fetch_s = "SELECT * FROM categories ORDER BY id DESC";
        $categories_s = mysqli_query($connection, $categories_fetch_s);

        $brands_fetch_s = "SELECT * FROM brands ORDER BY id DESC";
        $brands_s = mysqli_query($connection, $brands_fetch_s);
        ?>


       <!-- search options -->
       <div class="col-sm-12">
         <div class="search-options mb-3">
           <form action="" method="GET">
             <div class="row">
               <div class="col-md-6">
                 <div class="form-row">
                   <div class="col-sm-6 mb-3 mb-md-0">
                     <label for="brand-name">Brand</label>
                     <select name="brand" id="brand-name" class="form-control">
                       <option value="">---Select Brand---</option>
                       <?php
                        while ($row = mysqli_fetch_assoc($brands_s)) {
                        ?>
                       <option value="<?php echo $row['id'] ?>">
                         <?php echo $row['brand_name'] ?>
                       </option>
                       <?php } ?>
                     </select>
                     <div class="invalid-feedback"></div>
                   </div>
                   <div class="col-sm-6 mb-3 mb-md-0">
                     <label for="category-name">Category Name</label>
                     <select name="category" id="category-name" class="form-control">
                       <option value="">---Select Category---</option>
                       <?php
                        while ($row = mysqli_fetch_assoc($categories_s)) {
                        ?>

                       <option value="<?php echo $row['id']; ?>">
                         <?php echo $row['category_name']; ?>
                       </option>

                       <?php } ?>
                     </select>
                   </div>
                 </div>
               </div>
               <div class="col-md-6">
                 <div class="form-row">
                   <div class="col-sm-8 mb-3 mb-md-0">
                     <label for="product-name">Product Name</label>
                     <input class="form-control" type="text" name="search_product_name" id="product-name"
                       placeholder="Product Name">
                   </div>
                   <div class="col-sm-4">
                     <div class="cmn-btn-design">
                       <button class="btn btn-search" name="search_option_btn" type="submit">Search</button>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </form>
         </div>
       </div>


       <div class="col-md-12">
         <div class="all-product-table table-responsive">
           <table class="table table-bordered">
             <thead>
               <tr>
                 <th>Sl</th>
                 <th class="col_p_name">Name</th>
                 <th>Quantity</th>
                 <th>Category</th>
                 <th>Brand</th>
                 <th>Price</th>
                 <th>Image</th>
                 <!-- <th>Created at</th> -->
                 <th>Action</th>
               </tr>

             </thead>
             <tbody>
               <?php
                $sl = 1;
                while ($row = mysqli_fetch_assoc($products)) {
                ?>
               <tr>
                 <td><?php echo $sl++ ?></td>
                 <td class="col_p_name"><?php echo $row['name'] ?></td>
                 <td><?php echo $row['quantity'] ?></td>
                 <td><?php echo $row['category_name'] ?></td>
                 <td><?php echo $row['brand_name'] ?></td>
                 <td>BDT <?php echo number_format($row['price'], 2) ?></td>
                 <td><img width="80px" src="./uploads/<?php echo $row['image'] ?>" alt=""></td>
                 <!-- <td><?php echo date('d-m-Y, h:i A', strtotime($row['created_at'])) ?></td> -->
                 <td>
                   <a href="product.php?edit=<?php echo $row['product_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                   <a href="product_details.php?product_details=<?php echo $row['product_id']; ?>"
                     class="btn btn-primary btn-sm">Details</a>
                   <a href="common_delete.php?product_delete=<?php echo $row['product_id'] ?>"
                     onclick="return checkDelete()" class="btn btn-danger btn-sm">Delete</a>
                 </td>
               </tr>
               <?php } ?>
             </tbody>
           </table>
         </div>
       </div>

       <div class="col-sm-12 my-3">
         <div class="col-sm-6 offset-sm-3">
           <nav aria-label="Page navigation example">
             <ul class="pagination cmn-pagi-design">
               <li class="page-item <?php echo ($pageNumber <= 1) ? 'disabled' : ''; ?>">
                 <a class="page-link" href="product.php?pageNumber=<?php if ($pageNumber <= 1) {
                                                                      echo "";
                                                                    } else {
                                                                      echo ($pageNumber - 1);
                                                                    } ?>" aria-label="Previous">
                   <span aria-hidden="true">&laquo;</span>
                   <span class="sr-only">Previous</span>
                 </a>
               </li>
               <?php
                for ($i = 0; $i < $totalPage; $i++) {
                ?>
               <li class="page-item <?php echo ($i + 1 == $pageNumber) ? 'active' : ''; ?>"><a class="page-link"
                   href="product.php?pageNumber=<?php echo $i + 1; ?>"><?php echo $i + 1; ?></a>
               </li>
               <?php
                }
                ?>
               <li class="page-item <?php echo ($pageNumber >= $totalPage) ? 'disabled' : ''; ?>">
                 <a class="page-link" href="<?php if ($pageNumber >= $totalPage) {
                                              echo "";
                                            } else {
                                              echo "product.php?pageNumber=" . ($pageNumber + 1);
                                            } ?>" aria-label="Next">
                   <span aria-hidden="true">&raquo;</span>
                   <span class="sr-only">Next</span>
                 </a>
               </li>
             </ul>
           </nav>
         </div>
       </div>
     </div>
   </div>
 </div>

 <?php include 'footer.php'; ?>
 <script language="JavaScript" type="text/javascript">
function checkDelete() {
  return confirm('Are you sure delete?');
}
 </script>