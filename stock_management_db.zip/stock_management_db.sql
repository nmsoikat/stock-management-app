-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2020 at 07:12 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock_management_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `user_name`, `email`, `password`, `created_at`) VALUES
(1, 'Ashik', 'khan', 'ctashiqkhan@gmail.com', '123456789', '2020-11-06 18:00:00'),
(2, 'Admin', 'admin', 'admin@gmail.com', '12345678', '2020-11-07 17:44:22'),
(3, 'Sykat', 'sykat', 'sykat@gmail.com', '12345678', '2020-11-07 17:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `created_at`) VALUES
(1, 'Samsung', '2020-11-06 20:56:26'),
(2, 'Nokia', '2020-11-07 09:48:50'),
(14, 'Asus', '2020-11-15 16:01:21'),
(15, 'LG', '2020-11-15 16:01:34'),
(16, 'PHILIPS', '2020-11-15 18:19:44'),
(17, 'Xiaomi', '2020-11-15 18:25:50');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`) VALUES
(1, 'Mobile', '2020-11-06 20:56:37'),
(7, 'Monitor', '2020-11-15 17:08:24'),
(8, 'TV', '2020-11-15 18:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `brand_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(225) DEFAULT NULL,
  `price` double(20,2) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `brand_id`, `name`, `quantity`, `price`, `description`, `image`, `created_at`) VALUES
(17, 8, 1, 'Samsung UA43N5100ARSER 43 inch Full HD LED TV', '10', 45000.00, 'Samsung UA43N5100ARSER 43 inch Full HD LED TV\r\nThe Samsung UA43N5100ARSER 43 inch Full HD LED TV has great sound for great entertainment, and no need for a separate system. Dive into your content with more immersive audio. Beamforming technology and 4Ch 40W sound surrounds with the dynamism of a concert hall. Get ready to embrace a full-blown audio experience with an unbelievable sound output, up to two times more powerful than a conventional TV. Immerse yourself into a breathtaking surround sound experience. The 4 Channel sound output from top and bottom of TV spreads out optimally in the entire room to give you an unparalleled cinematic sound quality. Give the music in your mobile the impact it needs. Connect your mobile to the TV via Bluetooth to take advantage of the 4Ch 40W audio. Enjoy immersive sound like you’re in a concert hall. Clean View reduces noise and interference, while enhancing colour and contrast for the crystal clear view. Enjoy everything with refined image quality. Bright, rich colours await. Wide Colour Enhancer improves your image quality and uncovers details with colours as they were meant to be seen. Enjoy HD TV in Digital era. Once you see high definition of TV with vivid and crisp details, you’ll never look back to standard definition or analog TVs. Get your mobile on the big screen wirelessly. You don’t need an AP (Access Point). With Wi-Fi Direct, Samsung’s mirroring technology gets you connected quickly. Plug your favourite entertainment and media into your TV – watch videos, play music, or view photos through a USB connection.', '1605801702.png', '2020-11-15 09:48:01'),
(18, 8, 1, 'Samsung UA49RU7100RSER 49\" Smart 4K Ultra HD LED TV', '3', 91900.00, 'Samsung UA49RU7100RSER 49\" Smart 4K Ultra HD LED TV\r\nThe Samsung UA49RU7100RSER 49\" Smart 4K Ultra HD LED TV Watch your favorite content with natural colors that deliver details as crisp as the real thing. Get a more colorful viewing experience. Watch HDR content with better clarity and detailed color expression. Samsung UHD TV gives you more accurate details in bright and dark scenes. Picture quality to move you, made possible by a single chip that orchestrates color, optimizes high contrast ratio, and masters HDR. You can now talk to QLED. Bixby is the assistant to your needs that goes beyond controlling your TV. It gets more exciting when all you need is One Remote that controls all your compatible devices and content. You’ve never been closer than this. With the big screen tv, the more details that come alive. You’ll experience every moment of the game, feel every explosion, and be right in the middle of the action. Everything gets very real on a bigger screen. Modern and polished, the sleek design of UHD TV naturally fills the contours of your space with simple design.', '1605801582.png', '2020-11-15 10:12:31'),
(20, 1, 1, 'Samsung Galaxy S20', '10', 20000.00, 'Operating System	Android\r\nOS Version	10 (Ten)\r\nUser Interface (ui)	One UI 2\r\nCPU	Octa-core (2x2.73 GHz Mongoose M5 & 2x2.50 GHz Cortex-A76 & 4x2.0 GHz Cortex-A55)\r\nGPU	Mali-G77 MP11\r\nChipset	Exynos 990 (7 nm+)\r\nMemory\r\nMemory Internal	128 GB, 256 GB\r\nMemory External	microSDXC (uses shared SIM slot)\r\nRam	8 GB\r\nCamera\r\nPrimary Camera	Triple: 12 MP, (wide)\r\n 	8 MP, (telephoto), 3X Optical Zoom\r\n  	12 MP, (ultrawide)\r\nSecondary Camera	32 MP\r\nCamera Features	LED Flash, Pano', '1605801362.png', '2020-11-15 12:32:42'),
(21, 7, 1, 'Samsung T55 27 Inch FHD (1920x1080) LED Curved Monitor (HDMI, DP, VGA, Speaker) #C27T550FDW/LC27T550FDNXZA', '2', 30000.00, 'Model - Samsung T55, Series - Regular, Shape - Curved, Display Size (Inch) - 27 Inch, Display Type - FHD LED Display, Display Resolution - 1920 x 1080, Aspect Ratio - 16:9, Maximum Brightness (cd/m2) - 250 cd/m2, Contrast Ratio - 3000:1 (Typ.), Refresh Rate (Hz) - 75Hz, Adaptive-Sync Technology - Yes (AMD), Bit Depth / Color Support - 16.7 million, Response Time (ms) - 4ms (Gray to Gray), Horizontal Viewing Angle - 178 Degree, Vertical Viewing Angle - 178 Degree, VGA Port - 1, HDMI Port - 1, DisplayPort (DP) - 1, Headphone Jack - Yes, Speaker (Built-in) - 5 Watt speakers, Power Consumption - 0.3W (Off Mode), 0.3W (DPMS), Certifications - TUV Rheinland, Operating System Compatibility - Windows 10, Tilt Adjustment - -3(+-2) - 20(+-2), Specialty - Introducing the boldest curve ever accomplished. This milestone, born from years of relentless innovation, changes the shape of visual display and pioneers the future of monitor technology. T55 received a high performance curved display (1000R) and eye comfort certificate for its superior 1000R curved display from TUV Rheinland; a leading international Testing , Inspection, and Certification body. Connect to all your favorite devices with a convenient HDMI, DP, and D-Sub triple interface. The built-in 5 Watt speakers make it even easier to get lost in your favorite movies or TV shows, without plugging in a speaker., Others - Curvature: 1000R, Dynamic Contrast Ratio: Mega, Power Type: External Adaptor, Power Supply Type: AC 100-240V 50/60Hz, Eco Saving Plus: Yes, Eye Saver Mode: Yes, FreeSync: YES, Flicker Free: Yes, Game Mode: Yes, Off Timer Plus: Yes, Display Port Version: 1.2, HDMI Version: 1.4, Audio Speaker: Stereo, Stand Type: SIMPLE,, Part No - C27T550FDW/LC27T550FDNXZA, Accessories - Power Cable Length: 1.5 m, HDMI Cable: Yes, Warranty - 3 Year', '1605800945.png', '2020-11-15 17:30:52'),
(24, 7, 1, 'Samsung 23.5 Inch Curved Full HD LED Monitor', '5', 15000.00, 'Model - Samsung C24F390FHW, Series - Business, Display Size (Inch) - 23.5 inch, Shape - Curved, Display Type - FHD LED Display, Display Resolution - 1920 x 1080, Brightness (cd/m2) - 250cd/m2, Contrast Ratio (TCR/DCR) - 3000:1, Response Time (ms) - 4ms, Refresh Rate (Hz) - 60Hz, VGA Port - 1, HDMI Port - 1, Viewing Angle - 178 degree (H & V), Color - Black, Warranty - 3 year', '1605800743.png', '2020-11-15 17:58:57'),
(25, 7, 16, 'PHILIPS 18.5 Inch 193V5LSB23/94 LED MONITOR (VGA Port)', '8', 5800.00, 'Mercury Free eco-friendly display\r\nPhilips monitors with LED backlighting are free of Mercury content, one of the most toxic natural substances, which affects humans and animals. This reduces the environmental impact of the display throughout its life-cycle, from manufacturing to disposal.\r\n\r\n \r\n\r\n \r\n\r\nModel - PHILIPS 193V5LSB23/94, Shape - Widescreen, Display Size (Inch) - 18.5 Inch, Display Type - WLED Backlight Display, Panel Type - TFT-LCD, Touch Screen - No, Display Resolution - 1366 x 768, Aspect Ratio - 16:9, Maximum Brightness (cd/m2) - 200cd/m2, Contrast Ratio - 700:1, Refresh Rate (Hz) - 60Hz, Bit Depth / Color Support - 8-bit (16.7 Million), Response Time (ms) - 5ms, Horizontal Viewing Angle - 90 degree, Vertical Viewing Angle - 65 degree, Dot Pitch - 0.30 mm, DVI Port - No, VGA Port - 1, HDMI Port - No, DisplayPort (DP) - No, Mini DisplayPort - No, USB - No, Thunderbolt - No, Headphone Jack - No, Speaker (Built-in) - No, Power Consumption - 13.74 W, Operating Temperature - 0 degree C - 40 degree C, Tilt Adjustment - +10 degree - -3 degree, Body Color - Black, Weight - 2.15 kg (with stand), 1.94 kg (without stand), Dimensions - 437 x 338 x 170mm (with stand), 437 x 273 x 48mm (without stand), Others - 16:09 (Aspect ratio), Effective viewing area 409.8 (H) x 230.4 (V), SmartContrast 10M:1, Pixel pitch 0.30 x 0.30mm, Viewing angle: 90 (H) / 65 (V), Mercury Free Long: LCD panel type TFT-LCD, Warranty - 3 year, Country of Origin - Netherlands, Made in/ Assemble - China', '1605464298.png', '2020-11-15 18:18:18'),
(26, 7, 14, 'Asus VL279HE 27 Inch Eye Care Monitor Full HD Monitor (HDMI, VGA)', '9', 24500.00, 'Model - Asus VL279HE, Shape - Widescreen, Display Size (Inch) - 27 Inch, Display Type - FHD LED Display, Panel Type - IPS, Touch Screen - No, Display Resolution - 1920 x 1080, Aspect Ratio - 16:9, Display Surface - Non-Glare, Maximum Brightness (cd/m2) - 250 cd/m2, Contrast Ratio - 1000:1 (Max), 100000000:1 (ASCR), Refresh Rate (Hz) - 75 Hz, Adaptive-Sync Technology - Yes, Bit Depth / Color Support - 8-bit (16.7 Million), Response Time (ms) - 5ms (Gray to Gray), Horizontal Viewing Angle - 178 degree, Vertical Viewing Angle - 178 degree, Dot Pitch - 0.311 mm, DVI Port - No, VGA Port - 1, HDMI Port - 1, DisplayPort (DP) - No, Mini DisplayPort - No, USB - No, Thunderbolt - No, Headphone Jack - No, Speaker (Built-in) - No, Power Consumption - &lt; 40 Watts, Certifications - Energy Star, BSMI, CB, CCC, CE, CU, ErP, FCC, J-MOSS, KCC, RoHS, TCO7.0, UL/cUL, VCCI, WEEE, WHQL, MEPS, RCM, TUV Flicker-free , eStandby, TUV Low Blue Light, Operating System Compatibility - Windows 7, 8.1, 10, Tilt Adjustment - +21.5 degree - -8.5 degree, Lock Slot - Kensington Lock, Body Color - Black, Weight - 5.3Kg (with Stand), 4.29Kg (without Stand), Dimensions - 614 x 437.7 x 208.4mm (with Stand), 614 x 437.7 x 46mm (without Stand), Specialty - Eye Care Monitor, Full HD monitor with IPS technology with stunningly wide 178 degree viewing angles, Up to 75Hz refresh rate with Adaptive-Sync/FreeSync technology to eliminate screen tearing and choppy frame rates for fast and smooth gaming, exclusive GamePlus with crosshair, timer, FPS counter, display alignment functions, TUV Rheinland Certification for Flicker-free and Low Blue Light technology to ensure a comfortable viewing experience, Slim and frameless design with VESA wall-mountable to save on desktop space, Slim, frameless, elegant, Perfect for multi-display setups, Viewing Perfection, 75Hz refresh rate with ASUS GamePlus, Protect eyes with ASUS Eye Care technology, Ultra-low Blue Light Monitor, Flicker-free Technology, 8 Modes SPLENDID Video Preset (sRGB Mode/Scenery Mode/Theater Mode/Standard Mode/Night View Mode/Game Mode/Reading Mode/Darkroom Mode), 3 Modes Skin-Tone Selection, 4 Modes Color Temperature Selection, QuickFit modes (Alignment Grid/Paper/Photo Modes), GamePlus modes (Crosshair/Timer/FPS Counter/Display Alignment), Low Blue Light, HDCP support, VividPixel, EyeCheck, FreeSync technology supported, Adaptive-Sync supported, Home and Office Monitor, Others - Color Saturation: 72%(NTSC), Display Viewing Area (HxV): 597.888 x 336.312 mm, Flicker free: Yes, SPLENDID Video Preset Modes: 8 Modes, Skin-Tone Selection: 3 Modes, Color Temperature Selection: 4 Modes, QuickFit (modes): Yes, GamePlus(modes): Yes, Low Blue Light: Yes, HDCP support: Yes, VividPixel: Yes, EyeCheck: Yes, FreeSync technology supported: Yes, Voltage: 100-240V, 50 / 60Hz, Slim Design: Yes, Frameless Design: Yes, USP: Slim, Frameless, Elegant design, Up to 75Hz refresh rate with Adaptive-Sync/FreeSync, Key Feature: IPS, FHD, 5ms, HDMI, D-Sub, Wall Mountable, Part No - VL279HE, Accessories - Power cord, Power adapter, Quick start guide, Warranty Card, Warranty - 3 Year, Country of Origin - Taiwan, Made in/ Assemble - China', '1605464678.png', '2020-11-15 18:24:37'),
(27, 1, 17, 'Xiaomi Redmi 9', '50', 14999.00, 'The phone is powered by a 2×2.0 GHz Cortex-A75 Octa-Core processor with Mediatek Helio G80 (12 nm) chipset. Connectivity options include 4G LTE, Wi-Fi 802.11 a/b/g/n/ac, dual-band, Bluetooth 5.0, USB Type-C, Wi-Fi Direct, Mobile hotspot, etc. This phone comes with a non-removable Li-Poly (Lithium Polymer) 5020mAh battery with 18W fast charging. Are you looking for the latest Xiaomi phones? Then visit Xiaomi Phones.', '1605464862.png', '2020-11-15 18:27:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
