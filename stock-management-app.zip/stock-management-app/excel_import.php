<?php
include 'db.php';
session_start();

if (isset($_POST["excel_import"])) {

    $file = $_FILES['excel_file']['tmp_name'];
    $handle = fopen($file, "r");
    $c = 0;
    while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {
        $category = $filesop[0];
        $brand = $filesop[1];
        $name = $filesop[2];
        $quantity = $filesop[3];
        $price = $filesop[4];
        $description = $filesop[5];
        $image = $filesop[6];
        $sql = "insert into products (category_id,brand_id,name,quantity,price,description,image) values ('" . $category . "','" . $brand . "','" . $name . "','" . $quantity . "','" . $price . "','" . $description . "','" . $image . "')";
        $result = mysqli_query($connection, $sql);

        $c = $c + 1;
    }

    if ($result) {
        $_SESSION['message'] = 'Product import successfully';
        header("Location: product.php");
    } else {
        echo 'Error';
    }
}