<?php

// ---------------- Create Product ---------------------//
// read category
$categories_fetch = "SELECT * FROM categories ORDER BY id DESC";
$categories = mysqli_query($connection, $categories_fetch);

//read brand
$brands_fetch = "SELECT * FROM brands ORDER BY id DESC";
$brands = mysqli_query($connection, $brands_fetch);


// Product Data Insert
if (isset($_POST['product_save'])) {
  $name = $_POST['name'];
  $category = $_POST['category'];
  $brand = $_POST['brand'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $description = $_POST['description'];


  //image uploads
  $temp = explode(".", $_FILES["image"]["name"]);
  $newfilename = round(microtime(true)) . '.' . end($temp);
  move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $newfilename);

  $sql = "INSERT INTO products (category_id,brand_id,name,price,quantity,description,image) 
      VALUES ('" . $category . "','" . $brand . "','" . $name . "','" . $price . "','" . $quantity . "', '" . $description . "','" . $newfilename . "')";
  $result = mysqli_query($connection, $sql);

  if ($result) {
    $_SESSION['message'] = 'Product add successfully';
    header("Location: product.php");
  } else {
    echo 'Error';
  }
}



// -----------------------GET - Update Product ----------------------//

// // read category
// $categories_fetch = "SELECT * FROM categories ORDER BY id DESC";
// $categories = mysqli_query($connection, $categories_fetch);

// //read brand
// $brands_fetch = "SELECT * FROM brands ORDER BY id DESC";
// $brands = mysqli_query($connection, $brands_fetch);

if (isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $record = mysqli_query($connection, "SELECT * FROM products WHERE product_id=$id");
  $product_row = mysqli_fetch_array($record);
}

//Product Data Update
if (isset($_POST['update'])) {

  $name = $_POST['name'];
  $category = $_POST['category'];
  $brand = $_POST['brand'];
  $price = $_POST['price'];
  $quantity = $_POST['quantity'];
  $description = $_POST['description'];
  $newfilename = $product_row['image'];

  $file_check =  $_FILES["image"]["name"];

  if ($file_check != '') {

    //image existing file delete
    unlink('./uploads/' . $newfilename);
    //image uploads
    $temp = explode(".", $_FILES["image"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    move_uploaded_file($_FILES["image"]["tmp_name"], "uploads/" . $newfilename);
  }

  $sql = "UPDATE products SET brand_id = $brand, category_id = $category, name = '" . $name . "', price = '" . $price . "', quantity = '" . $quantity . "', description='" . $description . "', image='" . $newfilename . "' WHERE product_id=$id ";

  if (mysqli_query($connection, $sql)) {
    $_SESSION['message'] = 'Product updated successfully';
    header("Location: product.php");
  } else {
    echo 'Error';
  }
}



// --------------------- Read Product Show into Table-------------------//
// For Pagination
/*
PageNumber
PerPage
Offset = (PageNumber - 1) * PerPage;
*/

if (isset($_GET['pageNumber'])) {
  $pageNumber = $_GET['pageNumber'];
} else {
  $pageNumber = 1;
}

$perPage = 5;
$offset = ($pageNumber - 1) * $perPage;

//Pagination View
$sql = "SELECT COUNT(*) as total_p FROM products";
$productCount = mysqli_query($connection, $sql);
$totalRow = mysqli_fetch_array($productCount)['total_p'];
$totalPage = ceil($totalRow / $perPage);

//  Product Data Read
$product_fetch = "SELECT * FROM products
          LEFT JOIN brands
          ON brands.id = products.brand_id
          LEFT JOIN categories
          ON categories.id = products.category_id ORDER BY products.product_id DESC
          LIMIT $perPage OFFSET $offset ";

//$product_fetch = "SELECT * FROM products ORDER BY id DESC";

$products = mysqli_query($connection, $product_fetch);
//    echo '<pre>';
//    print_r(mysqli_fetch_assoc($products));
//    die();


// ------------------ Search Product ----------------------//
if (isset($_GET['search_option_btn'])) {
  $name = $_GET['search_product_name'];
  $category = $_GET['category'];
  $brand = $_GET['brand'];

  // print_r($name);
  // print_r($category);
  // print_r($brand);
  // name LIKE '%" . $name . "%' OR 

  if ($name && $category && $brand) {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id
    WHERE categories.id = '" . $category . "' 
    AND brands.id = '" . $brand . "'
    AND name LIKE '%" . $name . "%'
    ORDER BY products.product_id DESC";
  } else if ($category && $brand) {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id
    WHERE categories.id = '" . $category . "' 
    AND brands.id = '" . $brand . "'
    ORDER BY products.product_id DESC";
  } else if ($category) {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id
    WHERE categories.id = '" . $category . "'
    ORDER BY products.product_id DESC";
  } else if ($brand) {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id
    WHERE brands.id = '" . $brand . "'
    ORDER BY products.product_id DESC";
  } else if ($name) {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id
    WHERE name LIKE '%" . $name . "%'
    ORDER BY products.product_id DESC";
  } else {
    $product_fetch_search = "SELECT * FROM products
    LEFT JOIN brands
    ON brands.id = products.brand_id
    LEFT JOIN categories
    ON categories.id = products.category_id 
    ORDER BY products.product_id DESC";
  }



  $products = mysqli_query($connection, $product_fetch_search);
}