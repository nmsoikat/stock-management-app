<?php
include 'header.php';
include 'db.php';

//product count
$sql = "SELECT COUNT(product_id) as p_id FROM products";
$result = mysqli_query($connection, $sql);
$product_count = mysqli_fetch_array($result);
// echo '<pre>';
// print_r($product_count);
// echo '</pre>';
// echo $product_count['COUNT(product_id)'];


//Brand count
$sql = "SELECT * FROM brands";
$result = mysqli_query($connection, $sql);
$brand_count = mysqli_num_rows($result);

//Category count
$sql = "SELECT * FROM categories";
$result = mysqli_query($connection, $sql);
$category_count = mysqli_num_rows($result);

?>




<div class="content-body">
  <div class="container">
    <div class="row my-5">
      <div class="col-md-12">

        <?php
                if (isset($_SESSION['login_success'])) { ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
          <?php echo $_SESSION['login_success']; ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php
                    unset($_SESSION['login_success']);
                } ?>

        <div class="count-area-wrap">
          <div class="row">
            <div class="col-md-4">
              <a href="product.php" class="count-area">
                <p><strong>Product</strong></p>
                <strong><?php echo $product_count['p_id']; ?></strong>
              </a>
            </div>
            <div class="col-md-4">
              <a href="brand.php" class="count-area">
                <p><strong>Brand</strong></p>
                <strong><?php echo $brand_count; ?></strong>
              </a>
            </div>
            <div class="col-md-4">
              <a href="category.php" class="count-area">
                <p><strong>Category</strong></p>
                <strong><?php echo $category_count; ?></strong>
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
    <div class="row">
      <div class="offset-sm-3 col-sm-6">
        <div class="temp-info">
          <h2 class="title">Stock Management Application</h2>
          <div class="members">
            <p class="member">Nur Mohammad Soikat <span class="badge">Roll: 40</span></p>
            <p class="member">MD.Ashik Kahn <span class="badge">Roll: 45</span></p>
            <p class="member">Talha Ahmed <span class="badge">Roll: 03</span></p>
            <p class="member">Knok Borua <span class="badge">Roll: 28</span></p>
            <p class="member">MD. Manna <span class="badge">Roll: 38</span></p>
          </div>
          <div class="description text-muted mt-3">
            We are using some technology to complete this application:
            <p>HTML, CSS, BOOTSTRAP, PHP, SQL, Apache + MariaDB</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>