<?php
include 'header.php';
include 'db.php';

//product count
$sql = "SELECT COUNT(product_id) as p_id FROM products";
$result = mysqli_query($connection, $sql);
$product_count = mysqli_fetch_array($result);
// echo '<pre>';
// print_r($product_count);
// echo '</pre>';
// echo $product_count['COUNT(product_id)'];


//Brand count
$sql = "SELECT * FROM brands";
$result = mysqli_query($connection, $sql);
$brand_count = mysqli_num_rows($result);

//Category count
$sql = "SELECT * FROM categories";
$result = mysqli_query($connection, $sql);
$category_count = mysqli_num_rows($result);


// Quantity Count
$sql = "SELECT SUM(quantity) as qty FROM products";
$result = mysqli_query($connection, $sql);
$product_qty_count = mysqli_fetch_array($result);


// Quantity Count
$sql = "SELECT MAX(price) as price FROM products";
$result = mysqli_query($connection, $sql);
$product_max_price = mysqli_fetch_array($result);

$max_price = $product_max_price['price'];
$sql = "SELECT product_id FROM products WHERE price = '" . $max_price . "'";
$result = mysqli_query($connection, $sql);
$max_price_product = mysqli_fetch_array($result);

?>




<div class="content-body">
  <div class="container">
    <div class="row my-5">
      <div class="col-md-12">

        <?php
        if (isset($_SESSION['login_success'])) { ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
          <?php echo $_SESSION['login_success']; ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php
          unset($_SESSION['login_success']);
        } ?>

        <div class="count-area-wrap">
          <div class="row">
            <div class="col-md-4">
              <a href="product.php" class="count-area">
                <p><strong>Product</strong></p>
                <strong><?php echo $product_count['p_id']; ?></strong>
              </a>
            </div>
            <div class="col-md-4">
              <a href="brand.php" class="count-area">
                <p><strong>Brand</strong></p>
                <strong><?php echo $brand_count; ?></strong>
              </a>
            </div>
            <div class="col-md-4">
              <a href="category.php" class="count-area">
                <p><strong>Category</strong></p>
                <strong><?php echo $category_count; ?></strong>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row my-5">
      <div class="col-md-6">
        <a href="product.php" class="count-area-total">
          <p>Total Product (by quantity)</p>
          <p><?php echo $product_qty_count['qty']; ?></p>
        </a>
      </div>
      <div class="col-md-6">
        <a href="product_details.php?product_details=<?php echo $max_price_product['product_id']; ?>"
          class="count-area-total">
          <p>Height Price Product In Store</p>
          <p><?php echo floor($product_max_price['price']); ?> BDT</p>
        </a>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="temp-info">
          <p class="title">Stock Management Application</p>
          <div class="members">
            <p class="member">Nur Mohammad Soikat <span class="badge">Roll: 40</span></p>
            <p class="member">Md.Ashiq Khan <span class="badge">Roll: 45</span></p>
            <p class="member">Md.Talha Ahmed <span class="badge">Roll: 03</span></p>
            <p class="member">Konak Ranjan Shil <span class="badge">Roll: 28</span></p>
            <p class="member">Md.Mahmudur Rahman<span class="badge">Roll: 23</span></p>
          </div>
          <div class="description text-muted mt-3">
            We are using some technology to complete this application:
            <p>HTML, CSS, BOOTSTRAP, PHP, SQL, Apache + MariaDB</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>