<?php include 'db.php'; ?>
<?php include 'header.php'; ?>

<?php

// Add new brand
if (isset($_POST['add'])) {
  $sql = "INSERT INTO brands (brand_name) VALUES ('" . $_POST['name'] . "')";
  $result = mysqli_query($connection, $sql);

  if ($result) {
    $_SESSION['message'] = 'Brand name created successfully';
    header("Location: brand.php");
  } else {
    echo 'Error';
  }
}


// Edit existing brand name

if (isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $record = mysqli_query($connection, "SELECT * FROM brands WHERE id=$id");
  $brand_row = mysqli_fetch_array($record);
}


// Update brand name
if (isset($_POST['update'])) {

  $name = $_POST['name'];
  $brand_id = $_POST['updateId'];

  $sql = "UPDATE brands SET brand_name = '" . $name . "' WHERE id='" . $brand_id . "'";

  if (mysqli_query($connection, $sql)) {
    $_SESSION['message'] = 'Brand name updated successfully';
    header("Location: brand.php");
  } else {
    echo 'Error';
  }
}


//Brands Data Read
$brands_fetch = "SELECT * FROM brands ORDER BY id DESC";
$brands = mysqli_query($connection, $brands_fetch);

?>

<div class="content-body">
  <div class="container">

    <div class="row">
      <div class="col-md-12">
        <!-- <h4 class="page-title">Product Brand</h4> -->
        <?php
        if (isset($_SESSION['message'])) { ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo $_SESSION['message']; ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php
          unset($_SESSION['message']);
        } ?>

      </div>
      <div class="col-md-12 mb-5">

        <div class="row">
          <div class="offset-md-1 col-md-10 offset-xl-3 col-xl-6">
            <div class="brand-name-form cmn-form-design">
              <form id="brand-name-form" action="" method="POST">
                <input type="hidden" name="updateId" value="<?php echo $id;  ?>">
                <h2 class="form-title">
                  <?php if (isset($brand_row["brand_name"])) {
                    echo 'Edit Brand Name';
                  } else {
                    echo '
                    Add New Brand Name
                    ';
                  } ?>
                </h2>
                <div class="form-group">
                  <label for="brand-name">Brand Name</label>
                  <input name="name" id="brand-name" type="text" class="form-control" placeholder="Type Brand Name"
                    value="<?php if (isset($brand_row["brand_name"])) {
                                                                                                                              echo $brand_row["brand_name"];
                                                                                                                            } ?>">
                  <div class="invalid-feedback"></div>
                </div>
                <?php if (isset($brand_row["brand_name"])) {
                  echo '
                  <div class="cmn-btn-design update">
                    <button class="btn" id="category-update" name="update" type="submit">Update</button>
                    </div>
                  ';
                } else {
                  echo '
                    <div class="cmn-btn-design">
                      <button class="btn" id="category-add" name="add" type="submit">Add</button>
                    </div>
                    ';
                } ?>

              </form>
            </div>
          </div>
        </div>
      </div>

      <div class="offset-md-2 col-md-8">
        <div class="brand-name-table table-responsive cmn-table-design">
          <table class="table table-bordered table-striped" id="data_table">
            <thead>
              <tr>
                <th>Sl</th>
                <th>Name</th>
                <!-- <th>Created at</th> -->
                <th>Action</th>
              </tr>

            </thead>
            <tbody>
              <?php
              $sl = 1;
              while ($row = mysqli_fetch_assoc($brands)) {
              ?>
              <tr>
                <td><?php echo $sl++ ?></td>
                <td><?php echo $row['brand_name'] ?></td>
                <!-- <td><?php echo date('d-m-Y, h:i A', strtotime($row['created_at'])) ?></td> -->
                <td>
                  <a href="brand.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm"
                    id="cmnEditBtn">Edit</a>
                  <a href="common_delete.php?brand_delete=<?php echo $row['id']; ?>" onclick="return checkDelete()"
                    class="btn btn-danger btn-sm">Delete</a>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>

        </div>
        <!-- <div class="box">
                    <div class="box-body">
                        <a class="btn btn-primary" href="brand_create.php">Add New</a>
                        <hr>


                    </div>
                </div> -->

      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>
<script language="JavaScript" type="text/javascript">
function checkDelete() {
  return confirm('Are you sure delete?');
}



// Data table First Column Width
const dataTable = document.getElementById("data_table")
// console.log(dataTable.querySelector("tr th:first-child").style)

dataTable.querySelector("tr th:first-child").style.cssText =
  "  max-width: 15px;min-width: 15px;padding-left: 5px;padding-right: 5px;"

dataTable.querySelector("tr th:last-child").style.cssText = "width:100px"
</script>