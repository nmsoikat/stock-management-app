-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2020 at 07:29 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock_management_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `user_name`, `email`, `password`, `created_at`) VALUES
(1, 'Ashik', 'khan', 'ctashiqkhan@gmail.com', '123456789', '2020-11-06 18:00:00'),
(2, 'Admin', 'admin', 'admin@gmail.com', '12345678', '2020-11-07 17:44:22'),
(3, 'Sykat', 'sykat', 'sykat@gmail.com', '12345678', '2020-11-07 17:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `created_at`) VALUES
(1, 'Samsung', '2020-11-06 20:56:26'),
(2, 'Nokia', '2020-11-07 09:48:50'),
(14, 'Asus', '2020-11-15 16:01:21'),
(15, 'LG', '2020-11-15 16:01:34'),
(16, 'PHILIPS', '2020-11-15 18:19:44'),
(17, 'Xiaomi', '2020-11-15 18:25:50');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`) VALUES
(1, 'Mobile', '2020-11-06 20:56:37'),
(7, 'Monitor', '2020-11-15 17:08:24'),
(8, 'TV', '2020-11-15 18:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `brand_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(225) DEFAULT NULL,
  `price` double(20,2) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `brand_id`, `name`, `quantity`, `price`, `description`, `image`, `created_at`) VALUES
(1, 1, 1, 'Samsung Galaxy A20', NULL, 15990.00, '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '1604696686.jpg', '2020-11-06 21:04:45'),
(17, 1, 2, 'Test Product1', '2', 80000.00, 'this is product descrition detailsss', '1605435084.png', '2020-11-15 09:48:01'),
(18, 1, 15, 'Redm 9 ', '5', 14500.00, 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful conten', '1605435152.png', '2020-11-15 10:12:31'),
(20, 7, 14, 'asdfasdf', '10', 10000.00, ' The following form displays search results combining more than one search term. HTML code used for the search form: PHP code used to perform the search: This section connects to SQL database to search for content within the table: This section handles the pagination of the search results:', '1605443563.', '2020-11-15 12:32:42'),
(21, 7, 15, 'Cool', '5', 55000.00, ' The following form displays search results combining more than one search term. HTML code used for the search form: PHP code used to perform the search: This section connects to SQL database to search for content within the table: This section handles the pagination of the search results:', '1605461452.png', '2020-11-15 17:30:52'),
(22, 1, 1, 'Sam', NULL, 3.00, '8000', 'lorem ipsum', '2020-11-15 17:51:09'),
(23, 1, 1, 'Sam', NULL, 8000.00, 'lorem ipsum', '', '2020-11-15 17:56:02'),
(24, 1, 1, 'Sam', '3', 8000.00, 'lorem ipsum', 'Build-Authentic-Confidence.jpg', '2020-11-15 17:58:57'),
(25, 7, 16, 'PHILIPS 18.5 Inch 193V5LSB23/94 LED MONITOR (VGA Port)', '8', 5800.00, 'Mercury Free eco-friendly display\r\nPhilips monitors with LED backlighting are free of Mercury content, one of the most toxic natural substances, which affects humans and animals. This reduces the environmental impact of the display throughout its life-cycle, from manufacturing to disposal.\r\n\r\n \r\n\r\n \r\n\r\nModel - PHILIPS 193V5LSB23/94, Shape - Widescreen, Display Size (Inch) - 18.5 Inch, Display Type - WLED Backlight Display, Panel Type - TFT-LCD, Touch Screen - No, Display Resolution - 1366 x 768, Aspect Ratio - 16:9, Maximum Brightness (cd/m2) - 200cd/m2, Contrast Ratio - 700:1, Refresh Rate (Hz) - 60Hz, Bit Depth / Color Support - 8-bit (16.7 Million), Response Time (ms) - 5ms, Horizontal Viewing Angle - 90 degree, Vertical Viewing Angle - 65 degree, Dot Pitch - 0.30 mm, DVI Port - No, VGA Port - 1, HDMI Port - No, DisplayPort (DP) - No, Mini DisplayPort - No, USB - No, Thunderbolt - No, Headphone Jack - No, Speaker (Built-in) - No, Power Consumption - 13.74 W, Operating Temperature - 0 degree C - 40 degree C, Tilt Adjustment - +10 degree - -3 degree, Body Color - Black, Weight - 2.15 kg (with stand), 1.94 kg (without stand), Dimensions - 437 x 338 x 170mm (with stand), 437 x 273 x 48mm (without stand), Others - 16:09 (Aspect ratio), Effective viewing area 409.8 (H) x 230.4 (V), SmartContrast 10M:1, Pixel pitch 0.30 x 0.30mm, Viewing angle: 90 (H) / 65 (V), Mercury Free Long: LCD panel type TFT-LCD, Warranty - 3 year, Country of Origin - Netherlands, Made in/ Assemble - China', '1605464298.png', '2020-11-15 18:18:18'),
(26, 7, 14, 'Asus VL279HE 27 Inch Eye Care Monitor Full HD Monitor (HDMI, VGA)', '9', 24500.00, 'Model - Asus VL279HE, Shape - Widescreen, Display Size (Inch) - 27 Inch, Display Type - FHD LED Display, Panel Type - IPS, Touch Screen - No, Display Resolution - 1920 x 1080, Aspect Ratio - 16:9, Display Surface - Non-Glare, Maximum Brightness (cd/m2) - 250 cd/m2, Contrast Ratio - 1000:1 (Max), 100000000:1 (ASCR), Refresh Rate (Hz) - 75 Hz, Adaptive-Sync Technology - Yes, Bit Depth / Color Support - 8-bit (16.7 Million), Response Time (ms) - 5ms (Gray to Gray), Horizontal Viewing Angle - 178 degree, Vertical Viewing Angle - 178 degree, Dot Pitch - 0.311 mm, DVI Port - No, VGA Port - 1, HDMI Port - 1, DisplayPort (DP) - No, Mini DisplayPort - No, USB - No, Thunderbolt - No, Headphone Jack - No, Speaker (Built-in) - No, Power Consumption - &lt; 40 Watts, Certifications - Energy Star, BSMI, CB, CCC, CE, CU, ErP, FCC, J-MOSS, KCC, RoHS, TCO7.0, UL/cUL, VCCI, WEEE, WHQL, MEPS, RCM, TUV Flicker-free , eStandby, TUV Low Blue Light, Operating System Compatibility - Windows 7, 8.1, 10, Tilt Adjustment - +21.5 degree - -8.5 degree, Lock Slot - Kensington Lock, Body Color - Black, Weight - 5.3Kg (with Stand), 4.29Kg (without Stand), Dimensions - 614 x 437.7 x 208.4mm (with Stand), 614 x 437.7 x 46mm (without Stand), Specialty - Eye Care Monitor, Full HD monitor with IPS technology with stunningly wide 178 degree viewing angles, Up to 75Hz refresh rate with Adaptive-Sync/FreeSync technology to eliminate screen tearing and choppy frame rates for fast and smooth gaming, exclusive GamePlus with crosshair, timer, FPS counter, display alignment functions, TUV Rheinland Certification for Flicker-free and Low Blue Light technology to ensure a comfortable viewing experience, Slim and frameless design with VESA wall-mountable to save on desktop space, Slim, frameless, elegant, Perfect for multi-display setups, Viewing Perfection, 75Hz refresh rate with ASUS GamePlus, Protect eyes with ASUS Eye Care technology, Ultra-low Blue Light Monitor, Flicker-free Technology, 8 Modes SPLENDID Video Preset (sRGB Mode/Scenery Mode/Theater Mode/Standard Mode/Night View Mode/Game Mode/Reading Mode/Darkroom Mode), 3 Modes Skin-Tone Selection, 4 Modes Color Temperature Selection, QuickFit modes (Alignment Grid/Paper/Photo Modes), GamePlus modes (Crosshair/Timer/FPS Counter/Display Alignment), Low Blue Light, HDCP support, VividPixel, EyeCheck, FreeSync technology supported, Adaptive-Sync supported, Home and Office Monitor, Others - Color Saturation: 72%(NTSC), Display Viewing Area (HxV): 597.888 x 336.312 mm, Flicker free: Yes, SPLENDID Video Preset Modes: 8 Modes, Skin-Tone Selection: 3 Modes, Color Temperature Selection: 4 Modes, QuickFit (modes): Yes, GamePlus(modes): Yes, Low Blue Light: Yes, HDCP support: Yes, VividPixel: Yes, EyeCheck: Yes, FreeSync technology supported: Yes, Voltage: 100-240V, 50 / 60Hz, Slim Design: Yes, Frameless Design: Yes, USP: Slim, Frameless, Elegant design, Up to 75Hz refresh rate with Adaptive-Sync/FreeSync, Key Feature: IPS, FHD, 5ms, HDMI, D-Sub, Wall Mountable, Part No - VL279HE, Accessories - Power cord, Power adapter, Quick start guide, Warranty Card, Warranty - 3 Year, Country of Origin - Taiwan, Made in/ Assemble - China', '1605464678.png', '2020-11-15 18:24:37'),
(27, 1, 17, 'Xiaomi Redmi 9', '50', 14999.00, 'The phone is powered by a 2×2.0 GHz Cortex-A75 Octa-Core processor with Mediatek Helio G80 (12 nm) chipset. Connectivity options include 4G LTE, Wi-Fi 802.11 a/b/g/n/ac, dual-band, Bluetooth 5.0, USB Type-C, Wi-Fi Direct, Mobile hotspot, etc. This phone comes with a non-removable Li-Poly (Lithium Polymer) 5020mAh battery with 18W fast charging. Are you looking for the latest Xiaomi phones? Then visit Xiaomi Phones.', '1605464862.png', '2020-11-15 18:27:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
